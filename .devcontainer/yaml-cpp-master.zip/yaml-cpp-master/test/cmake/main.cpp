#include "yaml-cpp/yaml.h"

int main(int, char**) { YAML::Parser foo{}; }
