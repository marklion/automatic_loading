# SM4签名生成器

这是一个基于SM4算法的签名生成工具，可以在Ubuntu 24.04系统上运行。

## 文件说明

- `SM4SignatureGenerator.java`: Java源代码文件
- `sm4_signature_generator.sh`: 主执行脚本
- `install.sh`: 环境安装脚本
- `build.sh`: 编译脚本
- `run_signature.sh`: 运行脚本（编译后自动生成）

## 使用方法

### 方法1: 交互式运行（推荐）
```bash
./sm4_signature_generator.sh
```
然后根据提示选择操作。

### 方法2: 直接运行
1. 安装环境:
   ```bash
   ./install.sh
   ```

2. 编译程序:
   ```bash
   ./build.sh
   ```

3. 运行程序:
   ```bash
   ./run_signature.sh <appKey> <appSecret> <timestamp>
   ```

## 参数说明

- `appKey`: 应用标识
- `appSecret`: 应用密钥
- `timestamp`: 时间戳（毫秒）

## 示例

```bash
./run_signature.sh testKey testSecret 1628764800000
```

## 系统要求

- Ubuntu 24.04 或兼容的Debian/Ubuntu系统
- 网络连接（用于下载依赖库）
