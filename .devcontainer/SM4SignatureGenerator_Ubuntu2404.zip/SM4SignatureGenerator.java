import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.Security;
import java.util.*;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class SM4SignatureGenerator {
    private static final String SM4 = "SM4";
    private static final String TRANSFORMATION = "SM4/ECB/PKCS7Padding";
    private static final String PROVIDER_NAME = "BC";

    public static void main(String[] args) throws Exception {
        String appKey = args[0];
        String appSecret = args[1];
        String timestamp = args[2];
        String originalStr = getOriginalStr(appKey, appSecret, timestamp);
        String signature = signature(originalStr, appSecret);
        System.out.println("signature: " + signature);
    }

    public static String sign(String appKey, String appSecret, String timestamp) throws Exception {
        String originalStr = getOriginalStr(appKey, appSecret, timestamp);
        return signature(originalStr, appSecret);
    }

    public static String getOriginalStr(String appKey, String appSecret, String timestamp) {
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("appSecret", appSecret);
        params.put("timestamp", timestamp);
        List<String> sortedKeys = new ArrayList<>(params.keySet());
        Collections.sort(sortedKeys);

        StringBuilder dataToEncrypt = new StringBuilder();
        for (String key : sortedKeys) {
            dataToEncrypt.append(params.get(key));
        }

        return dataToEncrypt.toString();
    }


    public static String signature(String dataToEncrypt, String secret) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        KeyGenerator keyGen = KeyGenerator.getInstance(SM4, PROVIDER_NAME);
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(secret.getBytes());
        keyGen.init(128, secureRandom);
        SecretKey secretKey = keyGen.generateKey();
        Cipher cipher = Cipher.getInstance(TRANSFORMATION, PROVIDER_NAME);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedData = cipher.doFinal(dataToEncrypt.getBytes(StandardCharsets.UTF_8));
        return Hex.toHexString(encryptedData);
    }
}
