#!/bin/bash

# 更新包列表
echo "更新包列表..."
apt update

# 安装OpenJDK 11或更高版本
echo "安装OpenJDK..."
apt install -y openjdk-11-jdk

# 安装Maven（用于处理依赖）
echo "安装Maven..."
apt install -y maven

# 下载Bouncy Castle库
echo "下载Bouncy Castle库..."
wget https://repo1.maven.org/maven2/org/bouncycastle/bcprov-jdk15on/1.70/bcprov-jdk15on-1.70.jar -O bcprov-jdk15on-1.70.jar

echo "安装完成！"
