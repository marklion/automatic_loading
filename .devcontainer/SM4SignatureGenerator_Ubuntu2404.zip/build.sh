#!/bin/bash

# 设置Java环境
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

# 检查Java是否安装
if ! command -v javac &> /dev/null
then
    echo "Java未安装，请先运行install.sh"
    exit 1
fi

# 编译Java文件
echo "编译Java文件..."
javac -cp ".:bcprov-jdk15on-1.70.jar" SM4SignatureGenerator.java

if [ $? -eq 0 ]; then
    echo "编译成功！"
else
    echo "编译失败！"
    exit 1
fi

# 创建运行脚本
cat > run_signature.sh << 'EOF'
#!/bin/bash

# 设置Java环境
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

# 检查参数
if [ $# -ne 3 ]; then
    echo "用法: $0 <appKey> <appSecret> <timestamp>"
    echo "示例: $0 testKey testSecret 1628764800000"
    exit 1
fi

# 运行程序
java -cp ".:bcprov-jdk15on-1.70.jar" SM4SignatureGenerator "$1" "$2" "$3"
EOF

chmod +x run_signature.sh

echo "编译完成，运行脚本已创建: run_signature.sh"
