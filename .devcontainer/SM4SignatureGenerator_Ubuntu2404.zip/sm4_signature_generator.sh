#!/bin/bash

# SM4签名生成器 - 主执行脚本

# 检查install.sh是否存在
if [ ! -f "install.sh" ]; then
    echo "错误: install.sh 文件不存在"
    exit 1
fi

# 检查build.sh是否存在
if [ ! -f "build.sh" ]; then
    echo "错误: build.sh 文件不存在"
    exit 1
fi

# 检查Java文件是否存在
if [ ! -f "SM4SignatureGenerator.java" ]; then
    echo "错误: SM4SignatureGenerator.java 文件不存在"
    exit 1
fi

echo "==========================================="
echo "    SM4签名生成器部署脚本"
echo "==========================================="

# 提示用户选择操作
echo "请选择操作:"
echo "1) 安装环境并编译"
echo "2) 仅编译"
echo "3) 运行程序"
echo "4) 退出"
read -p "请输入选项 (1-4): " choice

case $choice in
    1)
        echo "开始安装环境..."
        bash install.sh
        if [ $? -eq 0 ]; then
            echo "环境安装成功，开始编译..."
            bash build.sh
        else
            echo "环境安装失败!"
            exit 1
        fi
        ;;
    2)
        echo "开始编译..."
        bash build.sh
        ;;
    3)
        if [ $# -eq 3 ]; then
            # 如果提供了参数，直接运行
            if [ -f "run_signature.sh" ]; then
                bash run_signature.sh "$1" "$2" "$3"
            else
                echo "错误: 程序尚未编译，请先编译!"
                exit 1
            fi
        else
            # 否则提示用户输入参数
            if [ -f "run_signature.sh" ]; then
                read -p "请输入appKey: " appKey
                read -p "请输入appSecret: " appSecret
                read -p "请输入timestamp: " timestamp
                bash run_signature.sh "$appKey" "$appSecret" "$timestamp"
            else
                echo "错误: 程序尚未编译，请先编译!"
                exit 1
            fi
        fi
        ;;
    4)
        echo "退出程序"
        exit 0
        ;;
    *)
        echo "无效选项!"
        exit 1
        ;;
esac
